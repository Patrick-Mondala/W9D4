module CatsHelper
end
